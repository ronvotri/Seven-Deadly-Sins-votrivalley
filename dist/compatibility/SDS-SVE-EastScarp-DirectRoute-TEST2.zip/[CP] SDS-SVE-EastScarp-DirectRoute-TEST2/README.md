# SDS × SVE × East Scarp Direct Route — TEST 2

Direct compatibility test route:

Town <-> EastScarp_Village

This build intentionally bypasses Custom_ShearwaterBridge.

Town gate:
- X110,Y72 -> EastScarp_Village 1,71
- X110,Y73 -> EastScarp_Village 1,72
- X110,Y74 -> EastScarp_Village 1,73

Return gate:
- EastScarp_Village X0,Y70-74 -> Town X109,Y72-74

IMPORTANT:
- Remove [CP] SDS-SVE-EastScarp-Compat-TEST1 before testing.
- Restart the game completely after installing.
- Test both directions.
